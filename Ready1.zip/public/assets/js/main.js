jQuery(function($){}); // ready

var validateOption = {
    //debug: true, // debug mode
    ignore: ".ignore",
    onclick: false, //Validate checkboxes and radio buttons on click
    errorClass: "invalid",
    errorElement: "span",
    onfocusout: false,
    onkeyup: false,
    messages: {
        name: {
            required: "Введите имя"
        },
        email: {
            required: "Введите E-mail"
        },
        phone: {
            required: "Введите телефон",
            digits: true

        },
        data: {
            required: "Введите дату"
        },
        number: {
            required: "Введите номер домика"
        }
    },
    highlight: function (element, errorClass, validClass) {
        $(element).addClass(errorClass).removeClass(validClass);
        setTimeout(function () {
            $(element).removeClass(errorClass);
            $(element).next().fadeOut(300);

        }, 1500);
    },
    unhighlight: function (element, errorClass, validClass) {
        $(element).removeClass(errorClass).addClass(validClass);
    },
    submitHandler: function (form) {
        ajaxSubmit.call(form);
    }

};

$(function () {

    var $form = $(".js-validate");
    // custom error messages
    jQuery.extend(jQuery.validator.messages, {
        required: "Поле не может быть пустым.",
        remote: "Поле заполнено неверно.",
        email: "Некорректный E-mail",
        phone: ""

    });

    $form.each(function () { // <- selects every <form> on set
        // init validation plugin
        $(this).validate(validateOption);

        // prevent default form submitted
        $(this).on("submit", function (e) {
            e.preventDefault();
        });
    });

}); //ready
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4uanMiLCJ2YWxpZGF0ZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbImpRdWVyeShmdW5jdGlvbigkKXt9KTsgLy8gcmVhZHlcclxuIiwidmFyIHZhbGlkYXRlT3B0aW9uID0ge1xyXG4gICAgLy9kZWJ1ZzogdHJ1ZSwgLy8gZGVidWcgbW9kZVxyXG4gICAgaWdub3JlOiBcIi5pZ25vcmVcIixcclxuICAgIG9uY2xpY2s6IGZhbHNlLCAvL1ZhbGlkYXRlIGNoZWNrYm94ZXMgYW5kIHJhZGlvIGJ1dHRvbnMgb24gY2xpY2tcclxuICAgIGVycm9yQ2xhc3M6IFwiaW52YWxpZFwiLFxyXG4gICAgZXJyb3JFbGVtZW50OiBcInNwYW5cIixcclxuICAgIG9uZm9jdXNvdXQ6IGZhbHNlLFxyXG4gICAgb25rZXl1cDogZmFsc2UsXHJcbiAgICBtZXNzYWdlczoge1xyXG4gICAgICAgIG5hbWU6IHtcclxuICAgICAgICAgICAgcmVxdWlyZWQ6IFwi0JLQstC10LTQuNGC0LUg0LjQvNGPXCJcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVtYWlsOiB7XHJcbiAgICAgICAgICAgIHJlcXVpcmVkOiBcItCS0LLQtdC00LjRgtC1IEUtbWFpbFwiXHJcbiAgICAgICAgfSxcclxuICAgICAgICBwaG9uZToge1xyXG4gICAgICAgICAgICByZXF1aXJlZDogXCLQktCy0LXQtNC40YLQtSDRgtC10LvQtdGE0L7QvVwiLFxyXG4gICAgICAgICAgICBkaWdpdHM6IHRydWVcclxuXHJcbiAgICAgICAgfSxcclxuICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgIHJlcXVpcmVkOiBcItCS0LLQtdC00LjRgtC1INC00LDRgtGDXCJcclxuICAgICAgICB9LFxyXG4gICAgICAgIG51bWJlcjoge1xyXG4gICAgICAgICAgICByZXF1aXJlZDogXCLQktCy0LXQtNC40YLQtSDQvdC+0LzQtdGAINC00L7QvNC40LrQsFwiXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGhpZ2hsaWdodDogZnVuY3Rpb24gKGVsZW1lbnQsIGVycm9yQ2xhc3MsIHZhbGlkQ2xhc3MpIHtcclxuICAgICAgICAkKGVsZW1lbnQpLmFkZENsYXNzKGVycm9yQ2xhc3MpLnJlbW92ZUNsYXNzKHZhbGlkQ2xhc3MpO1xyXG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAkKGVsZW1lbnQpLnJlbW92ZUNsYXNzKGVycm9yQ2xhc3MpO1xyXG4gICAgICAgICAgICAkKGVsZW1lbnQpLm5leHQoKS5mYWRlT3V0KDMwMCk7XHJcblxyXG4gICAgICAgIH0sIDE1MDApO1xyXG4gICAgfSxcclxuICAgIHVuaGlnaGxpZ2h0OiBmdW5jdGlvbiAoZWxlbWVudCwgZXJyb3JDbGFzcywgdmFsaWRDbGFzcykge1xyXG4gICAgICAgICQoZWxlbWVudCkucmVtb3ZlQ2xhc3MoZXJyb3JDbGFzcykuYWRkQ2xhc3ModmFsaWRDbGFzcyk7XHJcbiAgICB9LFxyXG4gICAgc3VibWl0SGFuZGxlcjogZnVuY3Rpb24gKGZvcm0pIHtcclxuICAgICAgICBhamF4U3VibWl0LmNhbGwoZm9ybSk7XHJcbiAgICB9XHJcblxyXG59O1xyXG5cclxuJChmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgdmFyICRmb3JtID0gJChcIi5qcy12YWxpZGF0ZVwiKTtcclxuICAgIC8vIGN1c3RvbSBlcnJvciBtZXNzYWdlc1xyXG4gICAgalF1ZXJ5LmV4dGVuZChqUXVlcnkudmFsaWRhdG9yLm1lc3NhZ2VzLCB7XHJcbiAgICAgICAgcmVxdWlyZWQ6IFwi0J/QvtC70LUg0L3QtSDQvNC+0LbQtdGCINCx0YvRgtGMINC/0YPRgdGC0YvQvC5cIixcclxuICAgICAgICByZW1vdGU6IFwi0J/QvtC70LUg0LfQsNC/0L7Qu9C90LXQvdC+INC90LXQstC10YDQvdC+LlwiLFxyXG4gICAgICAgIGVtYWlsOiBcItCd0LXQutC+0YDRgNC10LrRgtC90YvQuSBFLW1haWxcIixcclxuICAgICAgICBwaG9uZTogXCJcIlxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgICRmb3JtLmVhY2goZnVuY3Rpb24gKCkgeyAvLyA8LSBzZWxlY3RzIGV2ZXJ5IDxmb3JtPiBvbiBzZXRcclxuICAgICAgICAvLyBpbml0IHZhbGlkYXRpb24gcGx1Z2luXHJcbiAgICAgICAgJCh0aGlzKS52YWxpZGF0ZSh2YWxpZGF0ZU9wdGlvbik7XHJcblxyXG4gICAgICAgIC8vIHByZXZlbnQgZGVmYXVsdCBmb3JtIHN1Ym1pdHRlZFxyXG4gICAgICAgICQodGhpcykub24oXCJzdWJtaXRcIiwgZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcblxyXG59KTsgLy9yZWFkeSJdfQ==
